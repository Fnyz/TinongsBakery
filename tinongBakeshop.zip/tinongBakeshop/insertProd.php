<?php

session_start();
require_once "./Model/Prod.php";
$prod = new Prod();




if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    if (isset($_POST['save'])) {



        $prod->prod = $_POST['prod'];
        $prod->price = $_POST['price'];
        $prod->quantity = $_POST['quan'];
        $prod->desc = $_POST['desc'];


        if ($prod->insertItem()) {
            $_SESSION['Saves'] = "PRODUCT IS SUCCESSFULLY ADDED!";
            header("Location: Product.php");
        };
    }
}
