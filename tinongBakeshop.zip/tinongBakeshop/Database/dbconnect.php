<?php

$conn = new mysqli('localhost', 'root', '202415', 'tinongsbakeshop') or die("Could not connect to mysql" . mysqli_error($con));
