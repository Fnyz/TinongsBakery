



<?php
include_once "./Database/Database.php";

class Saless extends Database
{

    public $prod_id;
    public $cus_id;
    public $sub_price;
    public $total_quan;
    public $trans_code;
    public $table = "trans_history";
    public $id;
    public $user_id;





    public function insertData()
    {


        $sql = "INSERT INTO " . $this->table . " (prod_id, cus_id, trans_code, sub_price, sub_quantity, created_date, user_id)
        VALUES (:prod_id, :cus_id, :trans_code,:sub_price, :sub_quantity, now(),:user_id)";
        $stmt = $this->getConnect()->prepare($sql);



        $stmt->bindParam(":prod_id", $this->prod_id);
        $stmt->bindParam(":cus_id", $this->cus_id);
        $stmt->bindParam(":trans_code", $this->trans_code);
        $stmt->bindParam(":sub_price", $this->sub_price);
        $stmt->bindParam(":sub_quantity", $this->total_quan);
        $stmt->bindParam(":user_id", $this->user_id);


        if ($stmt->execute()) {

            return true;
        }
    }

    public function showTrans()
    {
        $sql = "select * from trans_history t inner join product p on t.prod_id = p.prod_id where trans_code = :trans_code";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":trans_code", $this->trans_code);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function userGet()
    {
        $sql = "select * from user_account where user_id = :user_id";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function totalPrice()
    {
        $sql = "select sum(sub_price) as total_price, sum(t.sub_quantity) as total_quan from trans_history t inner join product p on t.prod_id = p.prod_id where trans_code = :trans_code";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":trans_code", $this->trans_code);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }


    public function deleteData()
    {
        $sql = "delete from trans_history where trans_id = :trans_id";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":trans_id", $this->id);
        if ($stmt->execute()) {
            return true;
        }
    }

    public function updateProduct()
    {
        $sql = "update product set prod_quan = :prod_quan where prod_id = :prod_id";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":prod_quan", $this->total_quan);
        $stmt->bindParam(":prod_id", $this->prod_id);
        if ($stmt->execute()) {
            return true;
        }
    }
    public function searchDuplicate()
    {
        $sql = "select * from trans_history where prod_id = :prod_id and trans_code = :trans_code";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":prod_id", $this->prod_id);
        $stmt->bindParam(":trans_code", $this->trans_code);
        $stmt->execute();
        $result = $stmt->rowCount();
        return $result;
    }
}








?>

